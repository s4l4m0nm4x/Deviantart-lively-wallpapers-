/**
 * The easiest way to take a break at work.
 * Just launch the fullscreen version here :
 * http://emilienleroy.fr/codepen/wu/
 * Press F11 and go take a coffee :p
 * 
 * Follow me :D
 * https://github.com/EmilienLeroy
 * https://codepen.io/emilienleroy/
 * https://twitter.com/EmilienLeroyIT
 */

//init percentage
let percentage = 0;
//init the current time
let currentTime;
//time of windows update in ms (default 5 min)
let time = 500000;
//refresh interval of the percentage in ms (default 1 seconde)
let refresh = 500;

//lively customisation variables.
var timer;
var _overflow = false;
var _percRate = 1; 

//on windows load
window.onload = function(){ 
    //get the begin current time
    currentTime = time;    
    //start the loading
    timer = setInterval(loading, refresh);
}

function loading(){
    //calucl the percentage time
    currentTime = currentTime - refresh;
    percentage = ((time-currentTime)*100)/time;
    percentage *= _percRate;
    
    //is the time isn't finish reload the function
    if(percentage > 100)
    {
    	if(!_overflow)
        {
        	//reset
        	currentTime = time;
        	percentage = 0;
        }

    }

    //display the percentage
    document.querySelector('#update__percentage').innerHTML = parseInt(percentage)+'% complete';
}

//lively properties: https://github.com/rocksdanister/lively/wiki/Web-Guide-IV-:-Interaction
function livelyPropertyListener(name, val)
{
  switch(name) {
    case "speed":
      _percRate = val;
      break;
    case "overflow":
      _overflow = val;
      break; 
    case "btnRestart":
	  reset();
      break; 
  }
}

function reset()
{   
	try{
		clearInterval(timer);
		currentTime = time;
		timer = setInterval(loading, refresh);
    }
    catch{}
}