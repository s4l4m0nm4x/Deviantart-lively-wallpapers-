function toggleInfo() {
	if (document.getElementById('info').style.display == "block") {
		document.getElementById('info').style.display = "none";
	} else {
		document.getElementById('info').style.display = "block";
	}
}